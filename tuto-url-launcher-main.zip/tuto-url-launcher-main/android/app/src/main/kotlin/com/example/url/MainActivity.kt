package com.example.url

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
